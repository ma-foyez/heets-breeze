 <!-- Bootstarp min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/bootstrap.min.css">
 <!-- All min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/all.min.css">
 <!-- Swiper bundle min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/swiper-bundle.min.css">
 <!-- Magnigic popup css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/magnific-popup.css">
 <!-- Animate css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/animate.css">
 <!-- Nice select css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/nice-select.css">
 <!-- Style css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/style.css">