<title>{{ $content->website_name }}</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<link rel="icon" href="{{ asset('uploads/content/' . $content->website_favicon) }}" type="image/x-icon">

 <!-- Bootstarp min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/bootstrap.min.css">
 <!-- All min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/all.min.css">
 <!-- Swiper bundle min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/swiper-bundle.min.css">
 <!-- Magnigic popup css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/magnific-popup.css">
 {{-- Font Family Link  --}}
 <link href="https://fonts.googleapis.com/css?family=Fira+Sans:300,400,500,600,700,800,900%7CPT+Serif:400,700"
  rel="stylesheet">
 <!-- Animate css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/animate.css">
 <!-- Nice select css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/nice-select.css">
 <!-- Style css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/styles/style.css">